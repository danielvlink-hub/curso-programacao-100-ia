#!/usr/bin/env bash
# =================================================================================================
# instalar.sh — instala o FastPousada (curso Programação 100% IA) no Linux, SEM precisar de root.
# Daniel, 08/11/2026: "gerar pacote linux na pasta curso\linux".
#
# O QUE FAZ
#   1. Copia o sistema para ~/FastPousada (pasta visível: navegadores "snap" não leem pastas escondidas).
#   2. Liga a API do curso como serviço do usuário (systemd --user): sobe sozinha e reinicia se cair.
#      Sem systemd, use ./iniciar.sh (sobe a API e abre o navegador).
#   3. Cria o atalho "FastPousada" no menu de aplicativos (abre o login no navegador padrão).
# DADOS: ~/.local/share/FacilApp/CursoApiSqlite (banco, chaves com permissão 600, logs). A API escuta só em 127.0.0.1.
# RUNTIME: o .NET já vem DENTRO do executável da API — não precisa instalar nada.
# Uso: bash instalar.sh
# =================================================================================================
set -euo pipefail

ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DESTINO="$HOME/FastPousada"
PORTA="${FACILAPP_PORT:-7777}"

echo "FastPousada — instalando em $DESTINO"

# 1) arquivos do sistema (o banco e as chaves ficam na pasta de dados e NÃO são tocados)
mkdir -p "$DESTINO"
if [ "$ORIGEM" != "$DESTINO" ]; then
  cp -r "$ORIGEM"/. "$DESTINO"/
fi
chmod +x "$DESTINO/api/FacilApp.Sqlite.Api" "$DESTINO"/*.sh

# 2) serviço do usuário (systemd)
if command -v systemctl >/dev/null 2>&1 && systemctl --user show-environment >/dev/null 2>&1; then
  mkdir -p "$HOME/.config/systemd/user"
  cat > "$HOME/.config/systemd/user/fastpousada-api.service" <<EOF
[Unit]
Description=FastPousada — FacilApp API SQL do curso (porta $PORTA)
After=network.target

[Service]
WorkingDirectory=$DESTINO/api
ExecStart=$DESTINO/api/FacilApp.Sqlite.Api
Environment=FACILAPP_PORT=$PORTA
Restart=on-failure
RestartSec=3

[Install]
WantedBy=default.target
EOF
  systemctl --user daemon-reload
  systemctl --user enable --now fastpousada-api.service
  echo "API ligada como serviço do usuário (systemctl --user status fastpousada-api)."
  echo "Para a API subir mesmo antes de você entrar na sessão: sudo loginctl enable-linger $USER"
else
  echo "systemd do usuário não disponível: use $DESTINO/iniciar.sh para subir a API e abrir o sistema."
fi

# 3) atalho no menu de aplicativos
mkdir -p "$HOME/.local/share/applications"
cat > "$HOME/.local/share/applications/fastpousada.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=FastPousada
Comment=Sistema da pousada do curso Programação 100% IA
Exec=$DESTINO/iniciar.sh
Icon=$DESTINO/icone.png
Terminal=false
Categories=Office;
EOF
chmod +x "$HOME/.local/share/applications/fastpousada.desktop"

# confere se a API respondeu
for i in $(seq 1 15); do
  if curl -fs "http://127.0.0.1:$PORTA/status" >/dev/null 2>&1; then
    echo "Pronto! API respondendo em http://127.0.0.1:$PORTA — abra \"FastPousada\" no menu (usuário: facilapp, senha: 1)."
    exit 0
  fi
  sleep 1
done
echo "Instalado. A API ainda não respondeu: rode $DESTINO/iniciar.sh (ou veja os logs em ~/.local/share/FacilApp/CursoApiSqlite/logs)."
