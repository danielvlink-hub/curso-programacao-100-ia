/* ==========================================================================
   SISTEMA DE PEDIDOS DE VENDAS - BANCO DE DADOS SQL ENGINE (JS)
   ========================================================================== */

const PEDIDOS_DB_KEY = 'PEDIDOS_SYSTEM_DB_V2';

class PedidosDatabaseEngine {
  constructor() {
    this.init();
  }

  init() {
    // Acesso defensivo: em iframe file:// (WinDev/offline) o localStorage
    // pode vir bloqueado (SecurityError) e derrubava a tela inteira, porque
    // esse acesso nao estava protegido por try/catch.
    let saved = null;
    try {
      saved = localStorage.getItem(PEDIDOS_DB_KEY);
    } catch (e) {
      console.error("localStorage indisponivel neste ambiente, usando semente padrao.", e);
    }
    if (saved) {
      try {
        const data = JSON.parse(saved);
        this.clientes = data.clientes || [];
        this.produtos = data.produtos || [];
        this.pedidos = data.pedidos || [];
        this.itens_pedido = data.itens_pedido || [];
        this.facilflow_logs = data.facilflow_logs || [];
        return;
      } catch (e) {
        console.error("Erro ao carregar DB de Pedidos, reiniciando semente.", e);
      }
    }
    this.seedDefaults();
  }

  save() {
    const data = {
      clientes: this.clientes,
      produtos: this.produtos,
      pedidos: this.pedidos,
      itens_pedido: this.itens_pedido,
      facilflow_logs: this.facilflow_logs
    };
    try {
      localStorage.setItem(PEDIDOS_DB_KEY, JSON.stringify(data));
    } catch (e) {
      console.error("Nao foi possivel salvar no localStorage neste ambiente.", e);
    }
  }

  seedDefaults() {
    const now = new Date();
    const formatDate = (daysOffset = 0) => {
      const d = new Date(now);
      d.setDate(d.getDate() + daysOffset);
      return d.toISOString().split('T')[0];
    };

    this.clientes = [
      { id: 1, cnpj: "12.345.678/0001-90", razas_social: "Mercado Silva Ltda", nome_fantasia: "Supermercado Silva", telefone: "(11) 98765-4321", email: "compras@silva.com.br", ultima_compra_data: formatDate(-15), prazo_habitual: "30 Dias" },
      { id: 2, cnpj: "98.765.432/0001-10", razas_social: "Oliveira & Cia Distribuidora", nome_fantasia: "Distribuidora Oliveira", telefone: "(11) 99887-1122", email: "compras@oliveira.com", ultima_compra_data: formatDate(-45), prazo_habitual: "30/60 Dias" },
      { id: 3, cnpj: "45.678.912/0001-33", razas_social: "Carlos Eduardo EPP", nome_fantasia: "Comércio Eduardo", telefone: "(21) 97654-3210", email: "eduardo@comercio.com", ultima_compra_data: formatDate(-120), prazo_habitual: "À Vista" },
      { id: 4, cnpj: "33.444.555/0001-77", razas_social: "Ana Costa Variedades ME", nome_fantasia: "Variedades Costa", telefone: "(31) 99123-8877", email: "ana@costa.com", ultima_compra_data: formatDate(-200), prazo_habitual: "Boleto 14 dias" },
      { id: 5, cnpj: "77.888.999/0001-22", razas_social: "Fernando Souza Materiais", nome_fantasia: "Souza Materiais", telefone: "(41) 98844-5566", email: "souza@materiais.com", ultima_compra_data: formatDate(-10), prazo_habitual: "30/60/90 Dias" }
    ];

    this.produtos = [
      { id: 101, codigo: "PROD-01", nome: "Ração Premium Cães 15kg", preco_tabela: 120.00, categoria: "Petshop", estoque: 85 },
      { id: 102, codigo: "PROD-02", nome: "Óleo Automotivo 20W50 1L", preco_tabela: 45.00, categoria: "Automotivo", estoque: 150 },
      { id: 103, codigo: "PROD-03", nome: "Cimento CP-II 50kg", preco_tabela: 38.50, categoria: "Construção", estoque: 300 },
      { id: 104, codigo: "PROD-04", nome: "Tinta Acrílica Branca 18L", preco_tabela: 280.00, categoria: "Construção", estoque: 40 },
      { id: 105, codigo: "PROD-05", nome: "Kit Ferramentas Profissional 110 pçs", preco_tabela: 350.00, categoria: "Ferramentas", estoque: 25 },
      { id: 106, codigo: "PROD-06", nome: "Caixa de Leite Integral 12x1L", preco_tabela: 68.00, categoria: "Alimentos", estoque: 200 }
    ];

    const todayStr = formatDate(0);
    const yesterdayStr = formatDate(-1);

    this.pedidos = [
      { id: 1001, numero: "PED-1001", cliente_id: 1, data_pedido: `${todayStr} 09:30`, prazo_pagamento: "30 Dias", valor_total: 680.00, status: "Aprovado", vendedor: "Vendedor Padrão" },
      { id: 1002, numero: "PED-1002", cliente_id: 2, data_pedido: `${todayStr} 11:15`, prazo_pagamento: "30/60 Dias", valor_total: 1400.00, status: "Faturado", vendedor: "Vendedor Padrão" },
      { id: 1003, numero: "PED-1003", cliente_id: 5, data_pedido: `${yesterdayStr} 15:40`, prazo_pagamento: "À Vista", valor_total: 450.00, status: "Aprovado", vendedor: "Vendedor Padrão" }
    ];

    this.itens_pedido = [
      { id: 1, pedido_id: 1001, produto_id: 101, quantidade: 4, preco_unitario: 115.00, subtotal: 460.00 },
      { id: 2, pedido_id: 1001, produto_id: 102, quantidade: 4, preco_unitario: 45.00, subtotal: 180.00 },
      { id: 3, pedido_id: 1002, produto_id: 104, quantidade: 5, preco_unitario: 280.00, subtotal: 1400.00 },
      { id: 4, pedido_id: 1003, produto_id: 105, quantidade: 1, preco_unitario: 350.00, subtotal: 350.00 },
      { id: 5, pedido_id: 1003, produto_id: 102, quantidade: 2, preco_unitario: 50.00, subtotal: 100.00 }
    ];

    this.facilflow_logs = [
      { id: 1, evento: "order.created", payload: JSON.stringify({ pedido: "PED-1001", cliente: "Mercado Silva Ltda", total: "R$ 680,00" }), disparado_em: `${todayStr} 09:30:12`, status: "200 OK" }
    ];

    this.save();
  }

  getClientesUltimos6Meses() {
    const hoje = new Date();
    const limite180Dias = new Date();
    limite180Dias.setDate(hoje.getDate() - 180);

    return this.clientes.filter(c => {
      if (!c.ultima_compra_data) return false;
      const dataCompra = new Date(c.ultima_compra_data);
      return dataCompra >= limite180Dias;
    });
  }

  buscarOuCadastrarCNPJ(cnpjInput) {
    const cleanCnpj = cnpjInput.trim();
    let cliente = this.clientes.find(c => c.cnpj.replace(/\D/g, '') === cleanCnpj.replace(/\D/g, ''));

    if (cliente) {
      return { cliente: cliente, isNovo: false, mensagem: `Cliente encontrado: ${cliente.razas_social}` };
    }

    const newId = this.clientes.length ? Math.max(...this.clientes.map(c => c.id)) + 1 : 1;
    const formattedCnpj = cleanCnpj.length === 14 
      ? cleanCnpj.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, "$1.$2.$3/$4-$5")
      : cleanCnpj;

    const novoCliente = {
      id: newId,
      cnpj: formattedCnpj,
      razas_social: `Empresa CNPJ ${formattedCnpj} Ltda`,
      nome_fantasia: `Fantasia ${formattedCnpj}`,
      telefone: "(11) 9" + Math.floor(10000000 + Math.random() * 90000000),
      email: `contato_${newId}@cliente.com.br`,
      ultima_compra_data: new Date().toISOString().split('T')[0],
      prazo_habitual: "30 Dias"
    };

    this.clientes.unshift(novoCliente);
    this.save();

    return { cliente: novoCliente, isNovo: true, mensagem: `★ Cliente Novo Cadastrado Automaticamente!` };
  }

  salvarPedido(dadosPedido, itensCarrinho) {
    const newId = this.pedidos.length ? Math.max(...this.pedidos.map(p => p.id)) + 1 : 1001;
    const numPedido = `PED-${newId}`;
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const valorTotal = itensCarrinho.reduce((acc, item) => acc + (item.quantidade * item.preco_unitario), 0);

    const novoPedido = {
      id: newId,
      numero: numPedido,
      cliente_id: parseInt(dadosPedido.cliente_id),
      data_pedido: timestamp,
      prazo_pagamento: dadosPedido.prazo_pagamento,
      valor_total: valorTotal,
      status: "Aprovado",
      vendedor: "Vendedor Padrão"
    };

    this.pedidos.unshift(novoPedido);

    itensCarrinho.forEach(item => {
      const newItemId = this.itens_pedido.length ? Math.max(...this.itens_pedido.map(i => i.id)) + 1 : 1;
      this.itens_pedido.push({
        id: newItemId,
        pedido_id: newId,
        produto_id: parseInt(item.produto_id),
        quantidade: parseInt(item.quantidade),
        preco_unitario: parseFloat(item.preco_unitario),
        subtotal: parseFloat(item.quantidade * item.preco_unitario)
      });
    });

    const cliente = this.clientes.find(c => c.id == dadosPedido.cliente_id);
    if (cliente) {
      cliente.ultima_compra_data = new Date().toISOString().split('T')[0];
    }

    this.save();

    if (window.FacilFlow) {
      window.FacilFlow.triggerWebhook("order.created", {
        pedido: numPedido,
        cliente: cliente ? cliente.razas_social : "Cliente",
        total: `R$ ${valorTotal.toFixed(2)}`,
        prazo: dadosPedido.prazo_pagamento
      });
    }

    return novoPedido;
  }

  getDashboardStats() {
    const todayStr = new Date().toISOString().split('T')[0];
    const totalPedidos = this.pedidos.length;
    const pedidosHoje = this.pedidos.filter(p => p.data_pedido.startsWith(todayStr));
    const vendasHojeR = pedidosHoje.reduce((acc, p) => acc + p.valor_total, 0);
    const faturamentoTotal = this.pedidos.reduce((acc, p) => acc + p.valor_total, 0);
    const ticketMedio = totalPedidos ? (faturamentoTotal / totalPedidos) : 0;
    const clientesAtendidos = new Set(this.pedidos.map(p => p.cliente_id)).size;

    return {
      totalPedidos,
      vendasHojeR,
      faturamentoTotal,
      ticketMedio,
      clientesAtendidos
    };
  }

  runSQLQuery(queryText) {
    const q = queryText.toLowerCase().trim();
    if (q.includes("from clientes")) return { status: "200 OK", rows: this.clientes, table: "clientes" };
    if (q.includes("from produtos")) return { status: "200 OK", rows: this.produtos, table: "produtos" };
    if (q.includes("from pedidos")) return { status: "200 OK", rows: this.pedidos, table: "pedidos" };
    if (q.includes("from itens_pedido")) return { status: "200 OK", rows: this.itens_pedido, table: "itens_pedido" };
    return { status: "200 OK", rows: this.pedidos, table: "pedidos" };
  }
}

window.DB = new PedidosDatabaseEngine();
