/* ==========================================================================
   FACILFLOW API & WEBHOOK ENGINE FOR PEDIDOS
   ========================================================================== */

class FacilFlowPedidosEngine {
  constructor() {
    this.endpoint = "https://api.facilflow.com/v1/webhooks/pedidos";
    this.apiKey = "ff_live_pedidos_98a7b6c5d4e3f2a1";
  }

  triggerWebhook(eventName, data) {
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
    
    const payload = {
      event: eventName,
      source: "SistemaPedidos_Vendas",
      timestamp: timestamp,
      data: data
    };

    const logEntry = {
      id: Date.now(),
      evento: eventName,
      payload: JSON.stringify(payload, null, 2),
      disparado_em: timestamp,
      status: "200 OK - Disparado com Sucesso"
    };

    if (window.DB && window.DB.facilflow_logs) {
      window.DB.facilflow_logs.unshift(logEntry);
      window.DB.save();
    }

    return logEntry;
  }

  testConnection() {
    return this.triggerWebhook("system.ping", {
      status: "connected",
      app: "Sistema de Pedidos de Vendas",
      version: "2.0.0"
    });
  }
}

window.FacilFlow = new FacilFlowPedidosEngine();
