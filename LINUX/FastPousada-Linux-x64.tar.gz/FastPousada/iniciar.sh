#!/usr/bin/env bash
# =================================================================================================
# iniciar.sh — abre o FastPousada: garante a API rodando e abre o login no navegador padrão.
# O QUE FAZ: se a API já responde (serviço), só abre o navegador; senão, sobe a API em segundo plano (log em
#   ~/.local/share/FacilApp/CursoApiSqlite/api-linux.out) e espera ela responder.
# =================================================================================================
set -u
PASTA="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORTA="${FACILAPP_PORT:-7777}"
DADOS="$HOME/.local/share/FacilApp/CursoApiSqlite"

if ! curl -fs "http://127.0.0.1:$PORTA/status" >/dev/null 2>&1; then
  if command -v systemctl >/dev/null 2>&1 && systemctl --user cat fastpousada-api.service >/dev/null 2>&1; then
    systemctl --user start fastpousada-api.service
  else
    mkdir -p "$DADOS"
    ( cd "$PASTA/api" && FACILAPP_PORT="$PORTA" nohup ./FacilApp.Sqlite.Api >"$DADOS/api-linux.out" 2>&1 & )
  fi
  for i in $(seq 1 20); do
    curl -fs "http://127.0.0.1:$PORTA/status" >/dev/null 2>&1 && break
    sleep 1
  done
fi

xdg-open "file://$PASTA/html/login_Geral.html" >/dev/null 2>&1 &
