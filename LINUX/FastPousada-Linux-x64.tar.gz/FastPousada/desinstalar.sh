#!/usr/bin/env bash
# =================================================================================================
# desinstalar.sh — tira o FastPousada do Linux.
# O QUE FAZ: desliga e remove o serviço do usuário, o atalho do menu e a pasta ~/FastPousada.
# DADOS (banco, chaves, logs em ~/.local/share/FacilApp/CursoApiSqlite) FICAM, a menos que use: bash desinstalar.sh --tudo
# =================================================================================================
set -u
if command -v systemctl >/dev/null 2>&1; then
  systemctl --user disable --now fastpousada-api.service >/dev/null 2>&1 || true
  rm -f "$HOME/.config/systemd/user/fastpousada-api.service"
  systemctl --user daemon-reload >/dev/null 2>&1 || true
fi
pkill -f "FastPousada/api/FacilApp.Sqlite.Api" >/dev/null 2>&1 || true
rm -f "$HOME/.local/share/applications/fastpousada.desktop"
rm -rf "$HOME/FastPousada"
if [ "${1:-}" = "--tudo" ]; then
  rm -rf "$HOME/.local/share/FacilApp/CursoApiSqlite"
  echo "FastPousada removido, inclusive o banco e as chaves."
else
  echo "FastPousada removido. Os dados ficaram em ~/.local/share/FacilApp/CursoApiSqlite (use --tudo para apagar)."
fi
